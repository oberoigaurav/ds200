import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

path = '/home/oberoi/Gobby/IISc/ds200/'


file_gdp = 'STATE_DOMESTIC_PRODUCT_AT_CURRENT_PRICES.csv'
file_highway = 'timeseries-indicator_total-length_national-highways_2004-2015.csv'
file_state_gdp = 'Net_District_Domestic_Product_At_Constant_2004_05_prices.csv'
gdp = pd.read_csv(path + file_gdp)
highway = pd.read_csv(path + file_highway)
state_gdp = pd.read_csv(path + file_state_gdp)

start_gdp_type = state_gdp.dtypes.index ## list of years
state_gdp = np.transpose(np.asarray(state_gdp)) ## year X income_type
state_gdp_states = state_gdp[0] ## total states + districts
state_gdp = state_gdp[1:,:]
gdp_type = gdp.dtypes.index ## list of income types
gdp = np.asarray(gdp) ## year X income_type
gdp_year = gdp[:,0] ## 2004 to 2013
gdp = gdp[:,1:]
highway_year = highway.dtypes.index ## 2004 to 2013
highway = np.asarray(highway)
highway_city = highway[:,0] ## highway for different cities
highway = np.transpose( highway[:,1:-2] ) ##year X city 


###################################################
################## SCATTER PLOT ###################

### all india len of highway
#highway_all_india = highway[1:,-1]
### gdp in lakh rs
#gdp_inc = gdp[1:,1]
#pci_inc = gdp[1:,-1]  
#gdp_combined = np.vstack((gdp_inc, pci_inc)) 
##data = np.vstack((highway_all_india, gdp_lr))
#fig = plt.figure(figsize = (5,4), dpi =250 ) 
#fig1 = fig.add_subplot(111)
#fig1.scatter(gdp_combined[1], highway_all_india, s=5,c='g', marker="o", label = "Per Capita Increase")
#fig1.scatter(gdp_combined[0], highway_all_india, s=5,c='r', marker="x", label = "GDP Increase")
#fig1.set_ylabel('Length of National Highways(km)')
#fig1.set_xlabel('Economic Growth(%)')
#fig1.set_title('Economic Growth vs Development')
#plt.legend(loc='upper left')
#
#
#####################################################
#################### Line Plot #####################
#
#gdp_inc = gdp[1:,1]
#ndp_inc = gdp[1:,3]
#pci_inc = gdp[1:,-1] 
#
#income =  np.vstack((gdp_inc, ndp_inc, pci_inc)) 
#highway_year = list(highway_year[2:-2])
#for i in range(len(highway_year)):
#    highway_year[i] = int(highway_year[i])
#highway_year = np.asarray(highway_year)
#fig = plt.figure(figsize = (5,4), dpi =250 ) 
#fig1 = fig.add_subplot(111)
#fig1.plot(highway_year,gdp_inc, 'o-', label = "GDP ")
#fig1.plot(highway_year,ndp_inc, 's-', label = "NDP ")
#fig1.plot(highway_year,pci_inc, '*-', label = "Per Capita")
#fig1.set_ylabel('Economic Growth(%)')
#fig1.set_xlabel('Year')
#fig1.set_title('Economic Growth vs Year')
#plt.legend(loc='lower right')


###################################################
################## Box Plot #####################

up = highway[:,27]
wb = highway[:,28]
telangana = highway[:,24]
raj = highway[:,21]
karnataka = highway[:,11]
maharastra = highway[:,13]
#delhi = highway[:,33]

highway_year = np.asarray(highway_year)
fig = plt.figure(figsize = (5,4), dpi =250 ) 
fig1 = fig.add_subplot(111)
fig1.boxplot([karnataka, maharastra, wb, up ], labels = ['Karnataka', 'Maharashtra', 'W. Bengal','U.P.'],patch_artist=True,vert=True)
fig1.set_ylabel('Length of National Highways(km)')
fig1.set_xlabel('Year')
fig1.set_title('Comparison of Highway lengths of different States')
fig1.grid()
